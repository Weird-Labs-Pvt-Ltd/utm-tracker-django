UTM_PARAMETERS = [
    'utm_source',
    'utm_medium',
    'utm_campaign',
    'utm_term',
    'utm_content',
    'gclid',
    'aclk',
    'fbclid', 
    'msclkid',
    'dclid',
    'yclid',
    'gclsrc',
    'utm_id',
    'utm_referrer',
    'twclid'
]
